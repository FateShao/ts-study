// 设置 perttier 插件,让 prettier 和 eslint 配合
module.exports = {
    tabWidth: 4,
    semi: true,
    singleQuote: true,
    printWidth: 120,
    trailingComma: 'none'
  };