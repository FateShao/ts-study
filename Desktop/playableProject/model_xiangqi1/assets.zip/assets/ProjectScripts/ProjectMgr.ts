import ComSingleton from '../Scripts/Common/Modules/SingletonModule/ComSingleton';
import UIControl from '../Scripts/Common/Modules/UIModule/UIControl';
import { UIID } from './UIID';
const { ccclass } = cc._decorator;

@ccclass
export default class ProjectMgr extends ComSingleton {
    /**
     * 配置项, 不归UIControl管理的可自己取值刷新视图
     */
    config = null;

    onGameStart() {
        //这里是整个游戏入口
    }
}
